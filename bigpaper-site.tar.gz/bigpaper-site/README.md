# Big Paper — artist site

Single-page site for Big Paper, a rapper from Chicago, IL.

Static HTML, CSS and JavaScript. No build step, no framework, no dependencies —
open `index.html` in a browser and it runs.

## Structure

```
index.html              markup and copy
assets/
  css/styles.css        all styling
  js/main.js            nav, scroll reveal, filmstrip, lightbox, mailing list
  img/
    hero.jpg            hero portrait (1920×1071)
    story.jpg           Story section portrait (820×1025)
    covers/             release artwork, 700×700 square
    photos/             gallery photos, 620×775 (4:5)
```

## Running it locally

Open the file directly:

```bash
open index.html          # macOS
xdg-open index.html      # Linux
```

Or serve it, which is closer to production:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Design system

Colours are sampled from the *Hinckley* artwork so the shell and the
cover art sit in the same temperature. They are defined once as custom
properties at the top of `styles.css`:

| Token          | Value     | Used for                                 |
| -------------- | --------- | ---------------------------------------- |
| `--ink`        | `#100D08` | page background — warm black, not neutral |
| `--ink-2`      | `#191410` | Story section background                 |
| `--ember`      | `#A8321B` | primary accent, from the Hinckley title   |
| `--flare`      | `#DA7535` | hover state, from the Tangerine cover     |
| `--parchment`  | `#E8DBBC` | the bio panel                             |
| `--bone`       | `#E5DCCB` | body text                                 |
| `--smoke`      | `#8A8172` | secondary text                            |

**Red only ever marks something interactive.** The two exceptions are the
"Out now" underline and the pull quote in the bio panel. If you find
yourself adding red to a static element, that is the rule being broken.

Type is Big Shoulders Display (a typeface commissioned by the City of
Chicago) for display, Archivo for body, and Courier Prime for labels,
dates and captions.

## Swapping in content

Every placeholder is marked `<!-- SWAP -->` in `index.html`. Search for
that string to find them all. See [CONTENT.md](CONTENT.md) for the full
checklist of what is still missing.

### Replacing an image

Drop the new file in over the old one, keeping the same filename and
aspect ratio, then update the `width` and `height` attributes on the
`<img>` tag if the pixel dimensions changed. Those attributes reserve
space while the image loads and prevent the layout jumping.

- covers — square, 700×700 or larger
- gallery photos — 4:5, 620×775 or larger
- hero — landscape, 1920px wide minimum

### Adding a release

Copy an existing `<a class="rel">` block in the Music section. The grid
is set to four columns; a fifth release will wrap to a second row, which
is fine. Mark features as `Feature · <lead artist>` rather than `Single`
so the credit is honest.

### Adding a gallery photo

Copy a `<figure class="shot">` block in the filmstrip. `main.js`
duplicates the whole run at load so the scroll loops seamlessly — do not
add duplicates by hand.

### Turning Live or Shop back on

Both sections currently render a "coming soon" state. The markup for
tour date rows and product cards was removed rather than left commented
out; it is in the git history if you want it back, or it can be rebuilt
from the same patterns used elsewhere.

## Before going live

- [ ] Set the real domain in the Open Graph tags in `<head>` — they
      currently point at `example.com` and social share cards will not
      work until they are absolute URLs on the real domain.
- [ ] Replace `booking@example.com` and `press@example.com`.
- [ ] Point the mailing list form at a real provider. It currently
      validates the address and shows a confirmation, but does not send
      anything anywhere.
- [ ] Add a favicon.
- [ ] Fill in the bio. It is the last placeholder a visitor would notice.

## Accessibility and browser support

The page is keyboard navigable, honours `prefers-reduced-motion` (the
filmstrip stops moving and becomes manually scrollable), and has no
horizontal overflow at any width down to 320px. Gallery photos open in a
lightbox that traps focus and closes on Escape.

Tested at 375px, 390px and 412px wide, and on desktop.
