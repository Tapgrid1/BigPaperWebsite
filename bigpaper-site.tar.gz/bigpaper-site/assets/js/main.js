(function(){
  document.getElementById('yr').textContent = new Date().getFullYear();

  var nav = document.getElementById('nav');
  function onScroll(){ nav.classList.toggle('stuck', window.scrollY > 40); }
  window.addEventListener('scroll', onScroll, {passive:true}); onScroll();

  var burger = document.getElementById('burger'), links = document.getElementById('links');
  burger.addEventListener('click', function(){
    var open = links.classList.toggle('open');
    burger.classList.toggle('open', open);
    burger.setAttribute('aria-expanded', open);
  });
  links.addEventListener('click', function(e){
    if(e.target.tagName === 'A'){
      links.classList.remove('open'); burger.classList.remove('open');
      burger.setAttribute('aria-expanded','false');
    }
  });

  var io = new IntersectionObserver(function(en){
    en.forEach(function(x){ if(x.isIntersecting){ x.target.classList.add('in'); io.unobserve(x.target); } });
  }, {threshold:.1, rootMargin:'0px 0px -60px 0px'});
  document.querySelectorAll('.rise').forEach(function(el){ io.observe(el); });

  // duplicate the strip in the DOM (not the file) so translateX(-50%) loops seamlessly
  var track = document.getElementById('track');
  Array.prototype.slice.call(track.children).forEach(function(n){
    var c = n.cloneNode(true);
    c.setAttribute('aria-hidden','true');
    c.setAttribute('tabindex','-1');
    track.appendChild(c);
  });

  var box = document.getElementById('box'),
      boxImg = document.getElementById('boxImg'),
      boxCap = document.getElementById('boxCap'),
      boxX = document.getElementById('boxX'), last = null;
  function open(fig, from){
    var img = fig.querySelector('img'), cap = fig.querySelector('figcaption');
    last = from;
    boxImg.src = img.getAttribute('src');
    boxCap.textContent = cap ? cap.textContent : '';
    box.classList.add('on'); boxX.focus();
  }
  function close(){ box.classList.remove('on'); if(last) last.focus(); }
  document.querySelectorAll('.shot').forEach(function(s){
    s.addEventListener('click', function(){ open(s, s); });
    s.addEventListener('keydown', function(e){
      if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); open(s, s); }
    });
  });
  boxX.addEventListener('click', close);
  box.addEventListener('click', function(e){ if(e.target === box) close(); });
  document.addEventListener('keydown', function(e){ if(e.key === 'Escape' && box.classList.contains('on')) close(); });

  var mail = document.getElementById('mail'), joinBtn = document.getElementById('join'), note = document.getElementById('note');
  joinBtn.addEventListener('click', function(){
    var v = mail.value.trim();
    if(!v || v.indexOf('@') < 1 || v.indexOf('.') < 3){
      note.textContent = 'Enter a valid email address.';
      note.style.color = 'var(--flare)'; mail.focus(); return;
    }
    note.textContent = "You're on the list.";
    note.style.color = 'var(--smoke)'; mail.value = '';
  });
  mail.addEventListener('keydown', function(e){ if(e.key === 'Enter') joinBtn.click(); });
})();
