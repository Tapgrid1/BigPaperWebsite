# Content still needed

Everything here is marked `<!-- SWAP -->` in `index.html`. Nothing on the
page is invented — where a fact was not known it was left as an obvious
placeholder rather than filled with a plausible guess.

## Blocking — a visitor would notice these

**Bio.** The Story panel currently reads as notes to self ("Two
paragraphs of real bio. Where he's from, how he started..."). This is the
most visible placeholder on the page.

Worth covering, based on what the photos already show: the Grammys red
carpet, the Quad Studios session, the Global Mixx Music & Film Forum.
Those are credibility the copy is not yet claiming.

**Streaming links.** All four release cards link to `#`. Needed for
Hinckley, Tangerine, Break It Down, and Options — plus the "All
platforms" link in the Music header.

**Release metadata.** Only Hinckley has a year.

| Release       | Type    | Year | Producer | Notes                        |
| ------------- | ------- | ---- | -------- | ---------------------------- |
| Hinckley      | Single? | 2026 | ?        | confirm single vs EP         |
| Tangerine     | Single? | ?    | ?        |                              |
| Break It Down | Single? | ?    | ?        |                              |
| Options       | Feature | ?    | ?        | credited "AC Style feat. Paper" |

**Email addresses.** `booking@example.com` and `press@example.com` are
placeholders and currently go nowhere.

## Open questions

**The Options credit.** The cover reads "AC Style feat. **Paper**", not
Big Paper. If that was an earlier name, the card may need a note saying
so — right now it is the one release where the artist name does not match
the rest of the site.

**Photo captions.** Only what is legible in each frame was captioned. Two
are unconfirmed:

- *Global Mixx* — the lanyard is readable, but the man in the green cap
  is not named. The screen behind him is showing a Twista track. If that
  is who it is, it is the single most valuable caption on the page and
  should say so.
- *Live — venue, year* — neither is known.

**Logo.** There is none. The nav and footer currently set the name in
Big Shoulders Display. The *Hinckley* cover has an ornate gilded
wordmark on the wooden sign that would be a strong source for a real
mark.

## Deferred by choice

**Live** and **Shop** render "coming soon" states rather than empty
grids. Both route the visitor somewhere useful — Live to booking, Shop
to the mailing list — so the sections are doing work while the content
catches up.

Turn them on when there are real dates or real products. Placeholder
tour rows and empty product cards read as a broken site, not an
early one.

## Asset notes

- The hero (1920×1071) and Story portrait are high resolution and hold
  up at full-bleed.
- The gallery photos vary in source quality and colour temperature —
  purple club light, fluorescent office, warm lobby. A matched-contrast
  pass would make them read as one body of work; it has deliberately not
  been applied.
- `photos/06-empire.jpg` is soft at full size. Fine in the strip, weakest
  in the lightbox.
